//
//  ImageSwitchTableViewCell.swift
//  Demo
//
//  Created by IEMacBook01 on 23/05/16.
//  Copyright © 2016 Iftekhar. All rights reserved.
//


class ImageSwitchTableViewCell: SwitchTableViewCell {

    @IBOutlet var arrowImageView : UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
