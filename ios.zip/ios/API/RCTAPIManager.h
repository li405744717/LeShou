//
//  RCTNativeManager.h
//  LeShou
//
//  Created by DP-K on 2018/6/25.
//  Copyright © 2018年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>
@interface RCTAPIManager : NSObject<RCTBridgeModule>

@end
