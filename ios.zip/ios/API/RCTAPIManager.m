//
//  RCTNativeManager.m
//  LeShou
//
//  Created by DP-K on 2018/6/25.
//  Copyright © 2018年 Facebook. All rights reserved.
//

#import "RCTAPIManager.h"
#import <React/RCTEventDispatcher.h>
#import <React/RCTEventEmitter.h>
@implementation RCTAPIManager
RCT_EXPORT_MODULE(IOSAPIManager);
RCT_EXPORT_METHOD(getSysVersion:(RCTResponseSenderBlock) callback){
  callback(@[[NSNull null],version()]);
}

//获取版本号
static NSString * version(){
  NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
  return [infoDictionary objectForKey:@"CFBundleShortVersionString"];
}
@end
