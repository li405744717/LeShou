//
//  RCTNotificationManager.m
//  LeShou
//
//  Created by DP-K on 2018/6/25.
//  Copyright © 2018年 Facebook. All rights reserved.
//

#import "RCTNotificationManager.h"

@implementation RCTNotificationManager
RCT_EXPORT_MODULE(RCTNotificationManager);

- (NSArray<NSString *> *)supportedEvents
{
  return @[@"UIEvent"];
}

-(instancetype)init{
  self = [super init];
  if(self){
    //监听触摸屏幕
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onTouch) name:@"UIEvent" object:nil];
  }
  return self;
}

//响应触摸屏幕
-(void) onTouch{
  //向js发送事件
  [self sendEventWithName:@"UIEvent" body:@"_"];
}
@end
