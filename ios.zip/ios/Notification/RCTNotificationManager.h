//
//  RCTNotificationManager.h
//  LeShou
//
//  Created by DP-K on 2018/6/25.
//  Copyright © 2018年 Facebook. All rights reserved.
//

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
@interface RCTNotificationManager : RCTEventEmitter <RCTBridgeModule>

@end
